from flask import Flask, url_for, request

app = Flask(__name__)


@app.route('/')
def base():
    return "Миссия Колонизация Марса"


@app.route('/index')
def index():
    return '''<title>Привет, Яндекс!</title>
    И на Марсе будут яблони цвести!'''


@app.route('/image_mars')
def image_mars():
    return f'''<title>Привет, Марс!</title>
    <h1>Жди нас, Марс!</h1>
    <img src="{url_for('static', filename='img/mars.png')}" 
           alt="здесь должна была быть картинка, но не нашлась">
           
    <br>Вот она какая, красная планета'''


@app.route('/promotion')
def promotion():
    text = 'Человечество вырастает из детства.'
    text += '</br>Человечеству мала одна планета.'
    text += '</br>Мы сделаем обитаемыми безжизненные пока планеты.'
    text += '</br>И начнем с Марса!'
    text += '</br>Присоединяйся!'
    return text


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
